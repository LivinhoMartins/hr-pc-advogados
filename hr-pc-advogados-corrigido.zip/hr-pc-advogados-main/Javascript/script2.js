document.addEventListener("DOMContentLoaded", () => {
  // 1. CRONÔMETRO DE PLANTÃO ATIVO
  const campoCronometro = document.getElementById("cronometro-plantao");
  let segundos = 0,
    minutos = 0;
  if (campoCronometro) {
    setInterval(() => {
      segundos++;
      if (segundos >= 60) {
        segundos = 0;
        minutos++;
      }
      campoCronometro.textContent = `${minutos < 10 ? "0" + minutos : minutos}:${segundos < 10 ? "0" + segundos : segundos}`;
    }, 1000);
  }

  // 2. MENU INTELIGENTE (GLASSMORPHISM NO SCROLL)
  const menu = document.getElementById("js-menu");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 50) {
      menu.classList.add("menu-scrolled");
    } else if (menu) {
      menu.classList.remove("menu-scrolled");
    }
  });

  // 3. LINKS DO WHATSAPP
  const botoesWhatsapp = document.querySelectorAll("a[href*='wa.me']");
  const hora = new Date().getHours();
  const msg = hora >= 18 || hora < 6
    ? "Olá! Estou com uma emergência médica relacionada ao meu plano de saúde e preciso de orientação jurídica."
    : "Olá! Recebi uma negativa do meu plano de saúde e gostaria de orientação jurídica.";
  const numeroTelefone = "5541984199902";

  botoesWhatsapp.forEach((botao) => {
    botao.href = `https://wa.me/${numeroTelefone}?text=${encodeURIComponent(msg)}`;
    botao.target = "_blank";
    botao.rel = "noopener noreferrer";
  });

  // 4. SCROLL REVEAL (ENTRADA FLUIDA)
  const secoes = document.querySelectorAll("section");
  const animarScroll = () => {
    secoes.forEach((s) => {
      if (s.getBoundingClientRect().top < (window.innerHeight / 5) * 4)
        s.classList.add("secao-visivel");
    });
  };
  animarScroll();
  window.addEventListener("scroll", animarScroll);
});
